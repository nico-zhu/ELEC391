%  Nyqlog makes a polar plot of the open 
%  loop transfer function h0(s) with
%  |h0(s)| on a dB scale. It supports
%  only continuous and monovariable systems.
%